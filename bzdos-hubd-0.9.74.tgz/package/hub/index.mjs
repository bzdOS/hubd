#!/usr/bin/env node
/**
 * hubd MCP server — stdio JSON-RPC 2.0, zero dependencies.
 * Architecture: dumb server, smart agents. All logic lives in lib/core.mjs.
 */
import readline from 'node:readline';
import path from 'node:path';
import {
  VERSION, tenantKey, runSync, runCardSet, runReport, runStatus, runGet, runSearch, runSectionAdd, runTaskAdd,
  runTaskList, runTaskUpdate, runTaskGet, runClaim, runClaimCheck, runRelease, runKanban, setAuthorTransport,
  setHubBase, ensureHubDirs, HUB, runResourceSet, runResourceList, runResourceGet, runGraph, ensureProtocol, harvestPrompt,
  runOnboarding, runWhatsNew, runInbox, runContext, runHeartbeat, runPresence, refreshPresenceSnapshot, runTrajectory, requireAuthor,
  envChecks, ackEnvNotices, capOutput, runAudit, runLint, runNext, runAgenda, runRules, runOperatorGet, ownerWaiting, runReflect, runPromote, runLaw,
  PRESET,
} from './lib/core.mjs';
import { runUsageAdd, runUsage } from './lib/usage.mjs';
import { runStats, taskCost } from './lib/stats.mjs';
import { runRecall } from './lib/recall.mjs';
import { queueWait, queueWaitAll, queueSummaryForBrief, queueAck, briefWithQueues, queueSendChecked } from './lib/queue.mjs';
import { sessionId, subscriberId } from './lib/session.mjs';
import { promptList, renderPrompt, templateNames } from './lib/prompts.mjs';
import { LEVELS, OBSTACLES, RESULTS, VERDICTS } from './lib/reflect.mjs';

/* The default views' sizes, here once, because a tool's description quotes them: under
 * HUBD_PRESET=small (see lib/core.mjs) they are shorter, and a description quoting the usual
 * numbers would tell the model it got everything when it did not. hub_context gets a view of its
 * own only there: its open tasks came to 14k characters on a live hub, the first thing a session
 * reads. */
const SMALL = PRESET === 'small';
const VIEW = SMALL
  ? { card: 2000, journal: 2, journalText: 160, entries: 5, tasks: 15, taskText: 120, contextTasks: 10, handoffs: 3, handoffText: 300 }
  : { card: 4000, journal: 5, journalText: 240, entries: 20, tasks: 50, taskText: 160, handoffs: 6, handoffText: 600 };

const TOOLS = [
  { name: 'hub_sync',
    description: 'Sync a project folder into the hub. Collects git facts automatically; pass digest (your own summary of state/next steps) and the card is rewritten.',
    inputSchema: { type: 'object', properties: {
      path: { type: 'string', description: 'Absolute path to the project folder' },
      name: { type: 'string', description: 'Project name (default: folder name)' },
      digest: { type: 'string', description: 'Agent-written summary: status, recent work, next steps, blockers' },
      agent: { type: 'string', description: 'the function you are performing, e.g. "dev-hubd". NOT which model you are — that is read from the transcript, and many sessions share a model. NOT a queue role either: a role is a mailbox (see hub_queue_wait), this is who is at it.' },
    }, required: ['path', 'agent'] } },

  { name: 'hub_card_set',
    description: 'Create or update a project card from just a name and a digest — no folder needed (unlike hub_sync). Use it to capture a project that is not a local git checkout, e.g. when harvesting a dialog. Preserves any hand-written frontmatter and Facts. To fix ONE stale line without touching the owner\'s framing, patch instead of replacing: `replace: [{from, to}]` and/or `appendLine` — a `from` that is not in the digest is an error, not a silent no-op.',
    inputSchema: { type: 'object', properties: {
      project: { type: 'string', description: 'project name or slug' },
      digest: { type: 'string', description: 'the card digest: 3-6 lines of current state (replaces the whole text — omit it when patching). Enforced, not advised: a digest over the hub\'s limit is refused, and so is an appendLine that starts with a date — a dated line is an event and belongs in hub_report, which writes the card section AND the journal.' },
      replace: { type: 'array', items: { type: 'object', properties: { from: { type: 'string' }, to: { type: 'string' } }, required: ['from', 'to'] }, description: 'patch: exact substrings to swap, each must occur exactly once in the current digest' },
      appendLine: { type: 'string', description: 'patch: one line to add at the end of the current digest' },
      by: { type: 'string', description: 'the function you are performing, e.g. "dev-hubd". NOT which model you are — that is read from the transcript, and many sessions share a model. NOT a queue role either: a role is a mailbox (see hub_queue_wait), this is who is at it.' },
      verbose: { type: 'boolean', description: 'return the card path, the patches applied and the new digest; by default the reply is {ok, project, section, bytes} (plus patched: <count> and rotated when they happened) — you just wrote the text, it is not echoed back' },
    }, required: ['project', 'by'] } },

  { name: 'hub_section_add',
    description: 'Append ONE line to ONE section of a project card, leaving everything around it untouched. This is how Gates / Metrics / Market and any hand-written section get written by a tool at all — hub_card_set only writes the digest, and the report router only reaches Decisions / Facts / Communication / Next step and your own Handoff section. For those, a normal hub_report with DECIDE:/FACT:/COMM:/NEXT:/HANDOFF: is still the right call; use this for the rest. A line set into a "Handoff <agent>" section is journaled as a handoff, as HANDOFF: is. The section is created if missing (you get created:true back — check it, a typo is how a card grows two nearly identical headings).',
    inputSchema: { type: 'object', properties: {
      project: { type: 'string' },
      section: { type: 'string', description: 'a key from hub sections (gates, metrics, market, ...) or the literal heading as it appears in the card' },
      text: { type: 'string', description: 'one line; it is stamped with the date' },
      provenance: { type: 'string', description: 'where this came from — a URL, a file, a command, a person. Recorded next to the line so a later reader can re-check it.' },
      mode: { type: 'string', enum: ['append', 'set'], description: 'default append. `set` REPLACES the section body — right for "the one next action", wrong for anything cumulative.' },
      by: { type: 'string', description: 'the function you are performing, e.g. "dev-hubd".' },
    }, required: ['project', 'section', 'text', 'by'] } },

  { name: 'hub_report',
    description: 'Append a session report to the shared journal: what was done / broken / blocked. Lines are routed by prefix: DECIDE: (what | why), FACT:, HYPO:, COMM:, NEXT:, DONE: <id>, TASK:, NOTE:, TO:, HANDOFF:. HANDOFF: lines replace your own "## Handoff <agent>" section of the card with where your work stands and the next step, dated, and file a `handoff` journal entry; hub_context hands it to the next session.',
    inputSchema: { type: 'object', properties: {
      project: { type: 'string', description: 'the project slug, as hub_status lists it' }, agent: { type: 'string' },
      text: { type: 'string' },
      kind: { type: 'string', enum: ['done', 'broken', 'blocked', 'note'], description: 'default: note' },
      private: { type: 'boolean', description: 'route this entry to the LOCAL-ONLY life braid (journal.life.jsonl — gitignored, never mesh-synced) and stamp it private. Prose only: DECIDE:/FACT:/COMM:/NEXT: write into a card, and cards are synced, so mixing the two would publish what you asked to keep local.' },
      force: { type: 'boolean', description: 'NEXT: replaces the card\'s next step. If the current step was set by an owner role, a non-owner NEXT: is refused with the step\'s text unless force is true. The response always carries nextReplaced {text, by, at} when a step was replaced, and the card keeps one dated `prev` line.' },
      staleDays: { type: 'integer', description: 'the reply carries digestAgeDays, and digestStale + a hint once the digest trails the project journal by this many days (default 7) — you are the one holding the facts that would fix it' },
      to: { type: 'string', description: 'addressee: a role ("orchestrator") or "fleet" — the entry stays public but readers filter by it. A TO: prefix inside the text body appends to this; the parameter and the prefix are merged.' },
      reflect: { type: 'object', description: 'the turn\'s reflection as fields, instead of the REFLECT block at the end of text (not with it). Checked: a value off a list or a missing field refuses the whole report. Stored on the journal entry, written into its text as the block, and counted by `hub reflect`. A REFLECT block in text is still read, not checked; the reply\'s reflect.problems says what a digest could not use.',
        properties: {
          level: { type: 'string', enum: LEVELS, description: 'turn (default): this turn, any role; head: a head\'s over its workers; fleet: the orchestrator\'s over the heads' },
          goal: { type: 'string', description: 'what the turn was meant to deliver' },
          result: { type: 'string', enum: RESULTS, description: 'done only if this report names an artifact' },
          obstacle: { type: 'string', enum: OBSTACLES },
          obstacle_fact: { type: 'string', description: 'the fact with a number or a quote (exit code, seconds, refusal text), or "not measured"; required unless obstacle is none, refused with none' },
          instead: { type: 'string', description: 'what you would do differently' },
          rule: { type: 'string', description: 'one rule for the prompt, or "none"' },
          decisions: { type: 'array', description: 'head and fleet only: the verdict on each proposal from below',
            items: { type: 'object', properties: { rule: { type: 'string' }, verdict: { type: 'string', enum: VERDICTS }, reason: { type: 'string' } }, required: ['rule', 'verdict'] } },
        }, required: ['goal', 'result', 'obstacle', 'instead', 'rule'] },
    }, required: ['project', 'agent', 'text'] } },

  { name: 'hub_status', description: 'Snapshot of every project at once: the latest digest of each, when it was last synced, and its open-task count, plus the most recent shared-journal entries. A project whose card has fallen behind its OWN journal carries digestStale {daysBehind, lastJournal} — the card still reads fresh while the work moved on. Best for orienting at the start of a session. For a deadline-sorted to-do list use hub_brief; for one project in depth use hub_get.',
    inputSchema: { type: 'object', properties: {
      staleDays: { type: 'integer', description: 'digest counts as behind after N days of journal it does not reflect, default 7' },
    } } },

  { name: 'hub_get', description: `ONE project in depth: its card, its recent journal entries and any active soft-locks. Compact by default — the card's first ${VIEW.card} chars (frontmatter, digest, facts, next step), the newest ${VIEW.journal} journal entries with text cut to ${VIEW.journalText} chars; full:true gives the whole card and 15 entries. Use after hub_status or hub_search points you at a project.`,
    inputSchema: { type: 'object', properties: { project: { type: 'string', description: 'project slug or name' } }, required: ['project'] } },

  { name: 'hub_context',
    description: 'Where am I — the first call of a session and the first call after a context compaction. Resolves which hub project YOUR working directory belongs to, most to least certain: a .hubd marker file (repo root, first line = project slug) · a project card\'s recorded sync path · the repo folder name as a last-resort guess (guessed:true, with the one-line fix in `hint`). Returns {project, via, root, guessed, digest, digestSetAt, digestSetBy, laws, digestAgeDays, digestStale?, openTasks, activeClaims, journalTail, handoffs, presenceHere, claimsTouched}, the fields that change least first. digestStale is the same verdict hub_status gives — a digest can be four months behind its own journal and still read as current; presenceHere lists live heartbeats whose cwd is under this root — who else is editing this checkout right now; journalTail is the last few entries of the project, so resuming reads state, not a summary; handoffs are the project\'s "## Handoff <agent>" sections as {agent, at, ageHours, text}, yours first and whole (own:true), then the newest ' + VIEW.handoffs + ' of the others cut to ' + VIEW.handoffText + ' chars (cut: the whole length). project is null with a hint if nothing matched.' +
      (SMALL ? ` Compact: the first ${VIEW.contextTasks} open tasks, each text cut to ${VIEW.taskText} chars; full:true for all of them whole.` : ''),
    inputSchema: { type: 'object', properties: {
      cwd: { type: 'string', description: "Absolute path to YOUR OWN current working directory — this cannot be inferred by the server (it may serve many agents in many directories), so pass it explicitly." },
      staleDays: { type: 'integer', description: 'digest counts as stale after N days of journal it does not reflect (same rule as hub_status), default 7' },
      journalTail: { type: 'integer', description: 'how many recent journal entries of the project to include, default ' + VIEW.journal },
      agent: { type: 'string', description: 'you — so `claimsTouched` (live claims whose glob covers a file changed here in the last recentMinutes) leaves your own claims out' },
      recentMinutes: { type: 'integer', description: 'window for claimsTouched, default 30' },
      handoffs: { type: 'integer', description: 'how many other agents\' handoffs to include, newest first, default ' + VIEW.handoffs },
    }, required: ['cwd'] } },

  { name: 'hub_search', description: 'Full-text search across every project card and the entire journal, archived months included. Returns each matching line with its location. START HERE whenever you know a keyword, a task id or a name but not which project owns it — searching once beats guessing project × status against hub_task_list, which is how sessions have actually wasted calls. Also the way to find where something was discussed or decided.',
    inputSchema: { type: 'object', properties: { query: { type: 'string', description: 'plain-text substring, case-insensitive' } }, required: ['query'] } },

  { name: 'hub_task_add',
    description: 'Add a task to the shared cross-project backlog.',
    inputSchema: { type: 'object', properties: {
      project: { type: 'string', description: 'the project slug, as hub_status lists it' },
      text: { type: 'string', description: 'what the task is, in a line or two' },
      importance: { type: 'string', enum: ['high', 'med', 'normal'], description: 'default normal' },
      deadline: { type: 'string', description: 'YYYY-MM-DD, or +Nd for N days from today (UTC), optional' },
      cat: { type: 'string', description: 'one of technical | communicative | decision | chore. Anything else is kept — as a tag, not a category: the four values are the axis every by-type number is counted on, so it stays closed.' },
      tags: { type: 'array', items: { type: 'string' }, description: 'free-form labels — the open vocabulary next to the closed cat one' },
      assignee: { type: 'string', description: 'agent name or owner, optional' },
      by: { type: 'string', description: 'the function you are performing, e.g. "dev-hubd". NOT which model you are — that is read from the transcript, and many sessions share a model. NOT a queue role either: a role is a mailbox (see hub_queue_wait), this is who is at it.' },
      depends_on: { type: 'array', items: { type: ['integer', 'string'] }, description: 'task ids this task waits on (bare number or a node-scoped id like "pine-3")' },
      resources: { type: 'array', items: { type: 'string' }, description: 'resource slugs this task touches (host/vm/service/...) — a structured link task → resource, not prose' },
      verbose: { type: 'boolean', description: 'return the whole task object; by default the reply is {ok, id, project, by, importance, cat, textPreview} — you just wrote the text, it is not echoed back' },
    }, required: ['project', 'text', 'by'] } },

  { name: 'hub_task_get',
    description: 'ONE task by id, plus what it is blocked by and what it blocks, and, once the hub holds sessions (hub sessions ingest), `cost`: the tokens its attempts spent, at list price, and the verdict on them. Use this when you know the id — do NOT go guessing project × status combinations with hub_task_list. Know a keyword but not the id? hub_search first.',
    inputSchema: { type: 'object', properties: {
      id: { type: ['integer', 'string'], description: 'bare number or a node-scoped id like "pine-3"' },
    }, required: ['id'] } },

  { name: 'hub_task_list',
    description: 'List backlog tasks. Filter by project and/or status; page with limit/offset. `total` is always the full matching count, so a page never reads as the whole backlog. Compact by default: at most ' + VIEW.tasks + ' tasks, each text cut to ' + VIEW.taskText + ' chars (full:true for whole texts, or hub_task_get for one). Looking for ONE task you can name? hub_task_get by id, or hub_search by keyword — both beat listing and scanning.',
    inputSchema: { type: 'object', properties: {
      project: { type: 'string' }, status: { type: 'string', enum: ['open', 'done', 'all'] },
      limit: { type: 'integer', description: 'page size' },
      offset: { type: 'integer', description: 'skip this many, for paging through a long backlog' },
    } } },

  { name: 'hub_task_update',
    description: 'Update a task: close it (status=done), reassign, reprioritise, edit text/deadline/cat.',
    inputSchema: { type: 'object', properties: {
      id: { type: ['integer', 'string'], description: 'bare number or a node-scoped id like "pine-3"' }, status: { type: 'string', enum: ['open', 'done'] },
      importance: { type: 'string', enum: ['high', 'med', 'normal'] },
      text: { type: 'string' }, deadline: { type: 'string', description: 'YYYY-MM-DD, or +Nd for N days from today (UTC)' },
      cat: { type: 'string', description: 'technical | communicative | decision | chore — anything else is kept as a tag instead' },
      tags: { type: 'array', items: { type: 'string' }, description: 'free-form labels; replaces the task\'s tag list' },
      assignee: { type: 'string' }, by: { type: 'string' },
      depends_on: { type: 'array', items: { type: ['integer', 'string'] }, description: 'task ids this task waits on' },
      resources: { type: 'array', items: { type: 'string' }, description: 'resource slugs this task touches' },
    }, required: ['id', 'by'] } },

  { name: 'hub_audit',
    description: 'Compare what the hub DECLARES with what actually happened, and turn each disagreement into an incident somebody owns. Checks: a money bet whose gate date passed with no decision since · a project whose share of the journal contradicts the MODE its card declares · owner buttons nobody pressed · a card that stopped following its own journal · tasks with no project. Read-only by default; `apply` files one incident task per finding and writes ONE report. Every finding quotes the rule it enforces with the date that rule was written (HUB/rules.json -> laws), because an engine\'s opinion carries no weight and your own past decision does. Findings are keyed, so a weekly run never files the same incident twice. NOT a dashboard: the numbers it prints (attention share, close rates) are a thermometer and are never filed as violations.',
    inputSchema: { type: 'object', properties: {
      days: { type: 'integer', description: 'window for the attention/close-rate numbers, default 7' },
      staleButtonDays: { type: 'integer', description: 'an owner button older than this is a finding, default 7' },
      apply: { type: 'boolean', description: 'file the incidents (requires by). Default false — look first.' },
      by: { type: 'string', description: 'required with apply: the function you are performing, e.g. "auditor-weekly"' },
    } } },

  { name: 'hub_lint',
    description: 'Every rule that CAN be checked, checked — the difference between a rule the hub enforces and one that is only written down somewhere. Reports a money bet whose gate has no date, and a human-owned communicative task with no prep it depends on (the owner would have to both prepare and decide). Each finding says whether the instance actually enforces it (HUB/rules.json -> strict, opt-in and empty by default) and quotes the local rule if one is declared. Read-only, never files anything.',
    inputSchema: { type: 'object', properties: {
      projects: { type: 'array', items: { type: 'string' }, description: 'restrict to these project slugs' },
    } } },

  { name: 'hub_next',
    description: 'The ONE task to do now, and why it won — not a list. Picking from a list is work, and a session that has to pick tends to pick the easy one. A task whose dependencies are still open is never eligible, however loud it is. Says explicitly when the chosen one is the owner\'s to press rather than an agent\'s.',
    inputSchema: { type: 'object', properties: {
      project: { type: 'string' }, assignee: { type: 'string' },
    } } },

  { name: 'hub_agenda',
    description: 'The day split by WHO CAN ACT: agent work ready now, the owner\'s buttons (owner_kind human, or assigned to a role declared in HUB/owner-roles.json), what is blocked and on what, overdue and due-soon. Different question from hub_brief (everything that is going on) and hub_inbox (what needs a decision): this one answers "what can I actually start", which a mixed list hides.',
    inputSchema: { type: 'object', properties: { project: { type: 'string' } } } },

  { name: 'hub_recall',
    description: 'What do we know about X — ranked across project cards, their sections, decisions, the journal and tasks, instead of hub_search\'s flat exact-substring list or hub_get\'s everything-about-one-project. Scoring is deterministic and readable: term coverage first, then where the line lives (a decision outranks a passing note), then recency. EVERY hit carries the date it was true as of and a stale flag — recall\'s real failure mode is handing over a two-month-old fact with this morning\'s confidence.',
    inputSchema: { type: 'object', properties: {
      query: { type: 'string', description: 'words that name the thing; stop-words (the, not, of, and their Russian counterparts) are dropped and listed back as `dropped`; a term matches at the start of a word, never inside one' },
      project: { type: 'string', description: 'only this project — a slug, or several comma-separated' },
      limit: { type: 'integer', description: 'default 20' },
      staleDays: { type: 'integer', description: 'a hit older than this is flagged stale, default 30' },
    }, required: ['query'] } },

  { name: 'hub_reflect',
    description: 'The reflection digest of one project, what a head reads instead of its workers\' reports in full: per role, how turns ended (result) and what got in the way (obstacle class), and how many found no work (idle: result no with obstacle none, never an obstacle); per class, the count and the latest 3 facts; the rules proposed more than once; how many rules held the fragment\'s example (exampleRule, never counted as a rule); the verdicts heads and the orchestrator gave. A rule\'s other wordings count with it (`variants`): two wordings sharing 40% of their words are one rule. Reads the report\'s reflect field and a REFLECT block in its text alike. Every key, and every value of each list, is present with zeros, so the shape never depends on the data. With `promote`, the candidates for the project\'s laws instead: a rule said 3 times by one role, or by 2 roles, in the window, not a law yet, each with the id hub_law rules on; and the laws the project has. Read-only.',
    inputSchema: { type: 'object', properties: {
      project: { type: 'string', description: 'the project; its aliases count as it' },
      since: { type: 'string', description: 'the window: a duration (7d, 12h, 30m) or a time (2026-10-01, 2026-10-01 14:00); default 7d' },
      level: { type: 'string', enum: LEVELS, description: 'only one level: turn (every role\'s own turn), head (a head\'s over its workers), fleet (the orchestrator\'s over the heads); default all' },
      promote: { type: 'boolean', description: 'the candidates for the project\'s laws and its laws, not the digest' },
    }, required: ['project'] } },

  { name: 'hub_law',
    description: 'A head\'s verdict on a candidate for its project\'s laws (hub_reflect with promote lists them, each with an id). accept: the rule becomes a law, a line in the card\'s Laws section that hub_context returns to every role of the project. reject: it leaves the list until it is said often enough again after the rejection. A project with a head on record is that head\'s to rule on, or a fleet role\'s. Either verdict is a journal line.',
    inputSchema: { type: 'object', properties: {
      project: { type: 'string' },
      id: { type: 'string', description: 'the candidate\'s id, as hub_reflect with promote lists it' },
      verdict: { type: 'string', enum: ['accept', 'reject'] },
      by: { type: 'string', description: 'the head ruling on it' },
      reason: { type: 'string', description: 'why, for a reject above all' },
      since: { type: 'string', description: 'the window the candidate was listed over; default 7d' },
    }, required: ['project', 'id', 'verdict', 'by'] } },

  { name: 'hub_usage_add',
    description: 'Record what only YOU can see about a piece of work: seconds, tokens, cost, model. The hub cannot observe any of these, so they arrive here explicitly and are reported back as SUPPLIED, never mixed with what the hub measured itself. At least one number is required — an empty entry would record a $0 session.',
    inputSchema: { type: 'object', properties: {
      agent: { type: 'string' }, project: { type: 'string' }, task: { type: ['integer', 'string'] },
      seconds: { type: 'number' }, tokensIn: { type: 'integer' }, tokensOut: { type: 'integer' },
      costUsd: { type: 'number' }, model: { type: 'string' },
    }, required: ['agent'] } },

  { name: 'hub_usage',
    description: 'What the work cost, over a window, per project and per agent — with a hard line between SUPPLIED (seconds/tokens/money, reported by clients through hub_usage_add: what the hub can neither measure nor read; a session\'s tokens are READ by hub_stats) and MEASURED (closed-task spans and journal events, the hub\'s own arithmetic). The split is the point: a cost number that mixes an observed span with a guessed rate gets quoted later as if someone had counted.',
    inputSchema: { type: 'object', properties: {
      days: { type: 'integer', description: 'default 7' }, project: { type: 'string' }, agent: { type: 'string' },
    } } },

  { name: 'hub_stats',
    description: 'What the sessions cost and what came of it, per task, model, role or day. Tokens are READ from the clients\' own databases (hub sessions ingest), bound to the task each role was ordered to work on (the queue header\'s "task #"); attempts and accept/reject are MEASURED from the journal (VERDICT: lines); `notional` is the tokens at the OpenRouter list price of their day (hub price pull), the one way to compare a free tier with a paid key. The same files give the same numbers, byte for byte. A task\'s attempts: task:<id>.',
    inputSchema: { type: 'object', properties: {
      group: { type: 'string', enum: ['task', 'model', 'role', 'day'], description: 'rows per; default task' },
      since: { type: 'string', description: '"7d", "12h" or a date; default everything' },
      project: { type: 'string' },
      task: { type: ['integer', 'string'], description: 'one task: its attempts, each with its role, models, tokens and verdict' },
      check: { type: 'boolean', description: 'prove every token is bound to a task, unbound, or a probe\'s' },
    } } },

  { name: 'hub_rules',
    description: 'The team constitution (AGENTS.md) over MCP: read it, or append an amendment. hubd mechanics live in the generated HUBD.md — this is the file where the rules YOU set live. An amendment is APPENDED under one dated, attributed heading and never edits a line already there: rewriting a rule destroys the record of what it used to say, which is exactly what hub_audit needs to quote.',
    inputSchema: { type: 'object', properties: {
      append: { type: 'string', description: 'the amendment, one line. Omit to read.' },
      by: { type: 'string', description: 'required with append' },
    } } },

  { name: 'hub_operator',
    description: 'The operator card: facts and preferences about the HUMAN — rhythm, what framing works, and the Boundaries section listing what is never collected. Belongs to no project and changes slower than any of them. Agents READ Boundaries and never edit it. Returns a scaffold and how to create it if there is no card yet.',
    inputSchema: { type: 'object', properties: {} } },

  { name: 'hub_brief',
    description: 'Morning brief across all projects: open tasks (deadlines first), journal since N hours, stale cards, cards whose digest trails their own journal (staleDigests — the misleading kind of stale), active claims, per-role queue depth with last-seen agent (broadcast roles are flagged fanout instead of a depth — their cursors are per-reader), and a buttons rollup ("N buttons waiting, oldest X days" — pending items in a human-owner queue, see HUB/owner-roles.json). Two things wait on the owner and they are NOT the same: buttonItems = each unanswered package in an owner queue (age, sender, subject); ownerWaiting = open tasks only the owner can move, with age and how far past deadline — invisible in every "what can I start" list because the answer there is "not this". `review` carries the top few hub_lint + hub_audit findings, one per kind, each quoting the rule it enforces with the date that rule was written: the audit rides on this call instead of waiting to be remembered. It reports only — nothing is filed without an explicit hub_audit({apply:true}) carrying somebody\'s name.',
    inputSchema: { type: 'object', properties: {
      hours: { type: 'integer', description: 'journal window, default 48' },
      staleDays: { type: 'integer', description: 'card considered stale after N days, default 7' },
      reviewLimit: { type: 'integer', description: 'how many finding KINDS to inline, default 3; 0 turns the review block off' },
    } } },

  { name: 'hub_kanban',
    description: 'The board as data: open tasks split into queued (unassigned) and in-progress (assigned), plus done-in-the-last-day, recent journal (inbox) and the newest 20 artifact deliveries apart from it (mail: kind delivery, read into from, to, name, bytes, sha256) — the same view the read-only web kanban renders. Each task carries blocked and overdue flags.',
    inputSchema: { type: 'object', properties: {} } },

  { name: 'hub_claim',
    description: 'Soft-lock a work area so other agents see it. Not enforced — informational. Write `area` as a path glob relative to the project root ("src/**/*.ts", "docs/{a,b}.md", "public/index.html", a bare directory) and hub_claim_check / hub_context can tell another agent that the file it opened is yours; prose is accepted but comes back `matchable:false`.',
    inputSchema: { type: 'object', properties: {
      project: { type: 'string' }, area: { type: 'string', description: 'a path glob relative to the project root; several joined with " + "' }, agent: { type: 'string' },
      ttlMin: { type: 'integer', description: 'default 240' }, note: { type: 'string' },
      task: { type: ['string', 'integer'], description: 'start a task from your work queue instead: the claim is on task:<id> in the task\'s project (project and area are then not needed). While it holds the task is in progress and not offered again; when it lapses the task is offered again.' },
    }, required: ['agent'] } },

  { name: 'hub_claim_check',
    description: 'Before editing a file: is it inside somebody\'s live claim? Returns {free, holders:[{agent, area, since, note}], mine, unmatchable} — `mine` are your own claims covering it (pass agent), `unmatchable` the prose claims on the project that no path can be tested against. Pure read. The lock is soft by constitution: this informs, it does not forbid — coordinate with the holder.',
    inputSchema: { type: 'object', properties: {
      path: { type: 'string', description: 'the file (absolute, or relative to the project root)' },
      project: { type: 'string', description: 'slug; resolved from the path (marker / sync path / folder name) when omitted' },
      agent: { type: 'string', description: 'you — so your own claims are reported as `mine`, not as holders' },
    }, required: ['path'] } },

  { name: 'hub_release',
    description: 'Release a soft-lock. Pass id, or project+area+agent, or task+agent (give a started task back to the work queue).',
    inputSchema: { type: 'object', properties: {
      id: { type: 'string' },
      project: { type: 'string' }, area: { type: 'string' }, agent: { type: 'string' },
      task: { type: ['string', 'integer'] },
    } } },

  { name: 'hub_heartbeat',
    description: 'Record that an agent is alive — call it each work cycle (right after hub_report, before the next hub_queue_wait) so MCP/headless agents show up in hub_presence the same way screen-scraped ones do, no human bridge needed. Overwrites this agent\'s one presence record; freshness is judged at read time from ttlMin (default 15min), the same pattern hub_claim uses. Also refreshes this node\'s published snapshot (presence.<node>.json) at most once every 5 minutes, so agents on OTHER nodes can see you at all — the directory itself is node-local and never syncs.',
    inputSchema: { type: 'object', properties: {
      agent: { type: 'string', description: 'your stable identity, e.g. your agent name' },
      role: { type: 'string', description: 'the queue role you work under, e.g. "hubd" — lets hub_brief pair queue depth with who is listening' },
      status: { type: 'string', description: 'free text, e.g. "working" / "waiting" / "blocked"' },
      task_id: { type: ['integer', 'string'], description: 'the task/id you are currently on, optional' },
      cwd: { type: 'string', description: 'your absolute working directory, optional' },
      ttlMin: { type: 'integer', description: 'minutes before this record counts as stale, default 15' },
      state: { type: 'string', description: 'what the loop is doing, as a field a supervisor reads without parsing status: turn | waiting | exit. The hub keeps state_since — when this state began — across heartbeats that repeat it.' },
      turn: { type: 'integer', description: 'number of the current or last turn' },
      turn_started: { type: 'string', description: 'when the current turn began, or "now"; carried while the turn number stays the same' },
      empty_count: { type: 'integer', description: 'consecutive empty polls while waiting' },
      silent_count: { type: 'integer', description: 'consecutive restarts of a model that produced no output' },
      exit_reason: { type: 'string', description: 'one line, with state=exit' },
    }, required: ['agent'] } },

  { name: 'hub_presence',
    description: 'The fleet roster as far as it can honestly be seen from here: this node\'s live registry plus every other node\'s published snapshot (presence.<node>.json, one small file per node, refreshed on heartbeat and on any tool call there, at most every 5 minutes). Each row carries `observedOn` — WHICH node saw that heartbeat — and `alsoOn` when one agent name turns up on several. Read `coverage` before believing any absence: it lists every current mesh member with the age of its snapshot, or null when it has published none, and `blindTo`/`note` say so outright. That distinction is the reason this tool exists in this shape — one role read as 383 minutes since heartbeat on one node and 5.9 days on another, nothing was stale and nothing had diverged, the registries were simply of different machines, and an orchestrator escalated "worker is dead" four times over 92 hours while the worker worked. A role nobody reports is invisible, which is NOT the same as dead.',
    inputSchema: { type: 'object', properties: {
      role: { type: 'string', description: 'filter to agents heartbeating under this role' },
      aliveOnly: { type: 'boolean', description: 'drop stale (TTL-expired) records, default false' },
      cwd: { type: 'string', description: 'only agents whose heartbeat cwd is this directory or under it — "who is in this checkout"' },
      project: { type: 'string', description: 'only agents whose heartbeat cwd resolves to this project (marker, sync path or folder name)' },
      memberDays: { type: 'integer', description: 'a node counts as a mesh member if it wrote within N days, default 30 — retired node names drop out of `coverage` on their own' },
    } } },

  { name: 'hub_resource_set',
    description: 'Create or update a resource — an infrastructure/topology entity: host, vm, service, endpoint, or provider. Structured attributes (type, address, os, provider, status) and typed relationships go in fields, NOT prose. Use this instead of describing infra inside a card digest.',
    inputSchema: { type: 'object', properties: {
      slug: { type: 'string', description: 'resource id, e.g. "vm1" or "board.example.com"' },
      type: { type: 'string', description: 'host | vm | service | endpoint | provider | ... (open vocabulary)' },
      address: { type: 'string', description: 'ip / hostname / url, optional' },
      os: { type: 'string' },
      provider: { type: 'string', description: 'libvirt | cloudflare | bare-metal | ...' },
      status: { type: 'string', description: 'live | down | planned | retired' },
      digest: { type: 'string', description: 'one-line description (keep prose minimal)' },
      edges: { type: 'object', description: 'typed relationships, merged with existing: {"runs_on":["hubd"],"depends_on":["postgres"]}. Values are target slugs.', additionalProperties: { type: 'array', items: { type: 'string' } } },
      attrs: { type: 'object', description: 'any other one-line attributes, merged with existing; an empty value removes the key. A role is a card of type "role": {"rank":"worker","project":"api","head":"[[api-head]]","idle_min":"40"}', additionalProperties: { type: 'string' } },
      by: { type: 'string', description: 'who is writing' },
    }, required: ['slug', 'by'] } },

  { name: 'hub_resource_list',
    description: 'List resource cards (hosts, vms, services, endpoints, providers). Optionally filter by type.',
    inputSchema: { type: 'object', properties: { type: { type: 'string' } } } },

  { name: 'hub_resource_get',
    description: 'One resource card plus its inbound and outbound typed relationships.',
    inputSchema: { type: 'object', properties: { slug: { type: 'string' } }, required: ['slug'] } },

  { name: 'hub_graph',
    description: 'The typed relationship graph across projects AND resources: who runs where, what depends on / deploys to / exposes what. Edges are frontmatter [[links]] keyed by relation (runs_on, depends_on, deploys_to, exposes, part_of, ...). Returns nodes, edges, and dangling links. Filter by project or type.',
    inputSchema: { type: 'object', properties: {
      project: { type: 'string', description: 'only edges touching this project/resource slug' },
      type: { type: 'string', description: 'only edges touching a node of this type' },
    } } },

  { name: 'hub_onboarding',
    description: 'Orientation for an agent that has never worked with this hub before: which channel to use for what (claim vs task vs report vs queue — the #1 mistake), the author rule, the session ritual, how to recover after a compaction. Call this FIRST the first time you connect. Default mode "short" is under 600 words and lists the sections of the full manual; mode "full" is the whole manual (~4000 words) — the same text as HUBD.md in the hub.',
    inputSchema: { type: 'object', properties: {
      mode: { type: 'string', enum: ['short', 'full'], description: 'default short' },
    } } },

  { name: 'hub_whatsnew',
    description: 'Personalized "what did I miss" — journal activity since YOUR OWN last hub_whatsnew call (tracked per agent name), not a fixed time window like hub_brief. Call this at the start of a session/sweep instead of re-reading hub_status/hub_brief from scratch; a never-seen agent gets a 24h window on its first call. Compact by default: the newest ' + VIEW.entries + ' entries, each text cut to ' + VIEW.journalText + ' chars; full:true for all of them whole. Also carries `review`: the top few hub_lint + hub_audit findings, one per kind, each quoting the rule it enforces and the date that rule was written — read-only, files nothing. The entry of a card write carries `card`: the sections, the card file\'s size after the write in bytes, and the change, so a card that reads older than a write you made is checked here, not in git.',
    inputSchema: { type: 'object', properties: {
      agent: { type: 'string', description: 'your stable identity, e.g. "orchestrator" or your agent name — reused across calls to compute the delta' },
      hours: { type: 'integer', description: 'fallback window in hours if this agent has no prior checkpoint yet, default 24' },
      project: { type: 'string', description: 'only entries of this project — a slug, or several comma-separated; the checkpoint still moves' },
      since: { type: 'string', description: '"checkpoint" (default: since your own last call — right after a night away, empty right after a context compaction), "session" (since this session began: everything it wrote itself included — use this after a compaction), or an ISO time' },
      reviewLimit: { type: 'integer', description: 'how many finding KINDS to inline, default 3; 0 turns the review block off' },
    }, required: ['agent'] } },

  { name: 'hub_inbox',
    description: 'What needs a DECISION right now, distilled from hubd data (not a time window like hub_brief): blocked reports, overdue open tasks, unassigned open tasks, and claim locks whose TTL expired but were never released. Returns {empty:true} when nothing needs attention — poll this instead of re-reading hub_status/hub_brief every cycle.',
    inputSchema: { type: 'object', properties: {
      hours: { type: 'integer', description: 'window for blocked-report scan, default 72' },
      agent: { type: 'string', description: 'your role — surfaces journal entries addressed to you (to: <you> or to: fleet)' },
    } } },

  { name: 'hub_trajectory',
    description: 'Deterministic dependency-graph plan over tasks\' depends_on — the probable trajectory as a critical PATH, not an ML forecast. Returns: ready (doable now, no open deps), blocked (with waitingOn ids), layers (Kahn topo-order — what unlocks when), criticalPath (longest dependency chain = ordering bound), cycles (dependency loops to fix). Use to see "given deps, what is the actual order / what is the critical path to a milestone". Weight is task-count now; weighted by real durations once logd records them.',
    inputSchema: { type: 'object', properties: {
      project: { type: 'string', description: 'optional: restrict the graph to one project' },
    } } },

  { name: 'hub_queue_send',
    description: 'Append a message to a role\'s queue (queues/<role>.<node>.queue.md) for cross-agent/cross-node handoffs. Delivered to whoever calls hub_queue_wait (or `hub queue wait`) for that role, here or on a mesh-synced peer node. Prose, not cargo: over 16 KB, or carrying a base64/hex run over 2 KB, a git diff, a git bundle or a PEM block, it is refused — put the artifact in a file and send its path, size and sha256. Refused too while the role already holds 50 unread messages or 256 KB: its reader is behind, check it before sending more.',
    inputSchema: { type: 'object', properties: {
      role: { type: 'string', description: 'queue/role to deliver to, e.g. "dev" or "owner"' },
      text: { type: 'string' },
      from: { type: 'string', description: 'who is sending — the function you are performing, e.g. "dev-hubd" or "orchestrator". NOT which model you are, and NOT the target role. Required like every other write: the delivered block says "from <sender>" forever.' },
      task: { type: ['integer', 'string'], description: 'the task id this message is ABOUT, if any. Stamped into the delivered block and handed back to the consumer, so a reply (a blocker, a HOLD, a result) can be reported onto the task instead of being lost with the message. A bare number that names one task is stamped as that task\'s whole id (taskAsGiven keeps what you sent). An id matching no task comes back as taskKnown:false — the ref is still recorded.' },
    }, required: ['role', 'text', 'from'] } },

  { name: 'hub_queue_wait',
    description: 'Block until new content lands in <role>\'s queue (this node\'s file plus any mesh-synced peer files for that role), then return it — a real long-poll, not a snapshot you have to re-poll. Returns {changed:false} if nothing arrives within timeout. If a delivered block names a task (see hub_queue_send), the ids come back as `tasks` — report the outcome onto those tasks, or the message is the only place the blocker ever existed. Local/stdio only (not available on the shared HTTP server). Use this instead of a sleep-and-recheck loop when waiting on an agent to report back via hub_queue_send.',
    inputSchema: { type: 'object', properties: {
      role: { type: 'string' },
      timeout: { type: 'integer', description: 'seconds to block, default 45, max 540. The default is deliberately short: MCP clients abort a tool call on their own timeout (commonly ~60s) and hubd cannot see that limit. Raise it only if you know your client tolerates a longer call.' },
      tasks: { type: 'boolean', description: 'work mode: also return `work` — your open, ready tasks, most urgent first, each with its claim and the latest messages about it — and wake as soon as one is offered (ready, not started). Start one with hub_claim({task, agent, ttlMin}); a lapsed claim offers it again, so a turn that did nothing loses nothing. Messages about a task that is already closed are held back (`skipped`): cancelling is closing.' },
    }, required: ['role'] } },

  { name: 'hub_queue_wait_all',
    description: 'Subscribe to EVERY role\'s queue at once and block until new content lands in ANY of them — for an orchestrator reacting to whichever agent reports first, instead of calling hub_queue_wait per role or ssh-ing into each host to poll. Returns {changed:true, events:[{role,node,text}, ...]} tagging which role/node each event came from, or {changed:false} on timeout. Uses its own offset bookkeeping — does NOT consume/steal messages from a role\'s own hub_queue_wait consumer, it only taps. Local/stdio only.',
    inputSchema: { type: 'object', properties: {
      timeout: { type: 'integer', description: 'seconds to block, default 45, max 540. The default is deliberately short: MCP clients abort a tool call on their own timeout (commonly ~60s) and hubd cannot see that limit. Raise it only if you know your client tolerates a longer call.' },
    } } },

  { name: 'hub_queue_ack',
    description: 'Confirm that a delivered queue block was processed, not just read. Without this, a zombie session that reads a block and dies looks exactly like a processed one — the sender sees pending=0 but gets no reply. Ack moves the block from "delivered" to "acked" so the sender can distinguish the two. Call this after you have acted on the block — the ack is your proof of work, and the sender can poll for unacked blocks.',
    inputSchema: { type: 'object', properties: {
      role: { type: 'string', description: 'the role whose queue the block was delivered to' },
      id: { type: ['string', 'integer'], description: 'block id — the `· id` in the delivered block header, as "pine-12"; a bare number for a block from before 0.9.54' },
    }, required: ['role', 'id'] } },
];

/* Per-tool output budgets (see capOutput in lib/core.mjs). Order matters: the FIRST key of a
 * plan is cut first when the payload is still too large, so every plan leads with its journal
 * or its most repetitive list and ends with the things a caller asked the tool for. A tool
 * absent from this table is already small by construction (single card, one record, counts). */
const OUTPUT_PLANS = {
  // buttonItems last on purpose: the plan cuts in the order listed, and a pending owner decision
  // is the least compressible thing in this answer (same reasoning as tasksOpen, one step further).
  hub_brief:      [['journalRecent', 30], ['queues', 40], ['staleCards', 20], ['staleDigests', 20], ['activeClaims', 20], ['tasksOpen', 40], ['buttonItems', 20]],
  hub_status:     [['recentJournal', 10], ['projects', 60]],
  // `card` is a STRING, cut by characters (capOutput handles both). Listed FIRST because an
  // over-long card is exactly what makes this answer unreadable, and the journal and claims beside
  // it are the parts a caller can least afford to lose.
  // hub_get, hub_whatsnew and hub_task_list are COMPACT by default, not just capped: on a live
  // hub they came to 6-11k tokens a call, and to about 2k compact. The card's head (frontmatter,
  // digest, facts, next step) and the newest few journal lines, cut, answer "where is this";
  // full:true is the rest.
  // The journal is oldest-first, so its tail is kept; whatsnew is newest-first, so its head is.
  hub_get:        [['card', VIEW.card], ['journal', VIEW.journal, { keep: 'tail', textMax: VIEW.journalText }], ['claims', 20]],
  hub_whatsnew:   [['entries', VIEW.entries, { textMax: VIEW.journalText }]],
  hub_search:     [['hits', 40]],
  hub_inbox:      [['blocked', 25], ['staleClaims', 25], ['overdue', 25], ['unassigned', 25], ['addressed', 25]],
  hub_kanban:     [['inbox', 30], ['mail', 20], ['doneToday', 30], ['queued', 60], ['inProgress', 60]],
  hub_task_list:  [['tasks', VIEW.tasks, { textMax: VIEW.taskText, drop: ['_origin'], dropEmpty: true }]],
  ...(SMALL ? { hub_context: [['openTasks', VIEW.contextTasks, { textMax: VIEW.taskText, drop: ['_origin'], dropEmpty: true }]] } : {}),
  hub_trajectory: [['layers', 30], ['blocked', 60], ['ready', 60]],
  hub_graph:      [['edges', 200], ['dangling', 50]],
  hub_presence:   [['agents', 60], ['coverage', 12]],
  hub_audit:      [['findings', 40]],
  hub_recall:     [['hits', 20]],
  // decisions first: what was already decided matters less to a head than what is proposed again.
  hub_reflect:    [['decisions', 30], ['rules', 30], ['candidates', 30]],
  hub_agenda:     [['blocked', 40], ['agentReady', 40], ['dueSoon', 20], ['overdue', 20], ['ownerButtons', 20]],
  hub_lint:       [['findings', 40]],
  hub_resource_list: [['resources', 100]],
  hub_stats:      [['rows', 40]],
};

// Every capped tool advertises the same escape hatch, injected in ONE place so that adding a
// plan above can never leave a tool whose output is trimmed with no documented way out.
for (const name of Object.keys(OUTPUT_PLANS)) {
  const t = TOOLS.find(x => x.name === name);
  if (!t) continue;
  t.inputSchema = t.inputSchema || { type: 'object', properties: {} };
  t.inputSchema.properties = t.inputSchema.properties || {};
  t.inputSchema.properties.full = { type: 'boolean', description: 'return everything, uncapped. By default long lists are trimmed (and, where the description says so, long texts cut) to fit an agent context, and what was left out is reported in `truncated`.' };
}

const DISPATCH = {
  hub_sync: runSync, hub_report: runReport, hub_status: (a) => runStatus(a),
  // Same reasoning as hub_task_add below: the digest was just written by the caller, and the reply
  // echoed it back with the card path, about 1k tokens a call.
  hub_card_set: (a) => {
    const r = runCardSet(a);
    if (a.verbose) return r;
    return { ok: true, project: r.project, section: 'Digest', bytes: r.bytes,
      ...(r.patched ? { patched: r.patched.length } : {}), ...(r.rotated ? { rotated: r.rotated } : {}) };
  },
  hub_section_add: runSectionAdd,
  hub_get: runGet, hub_search: runSearch, hub_context: (a) => runContext({ ...a, journalTail: a.journalTail ?? VIEW.journal, handoffs: a.handoffs ?? VIEW.handoffs, handoffText: VIEW.handoffText }),
  // The caller wrote the text a moment ago; echoing 2-3 KB of it back is context spent on nothing
  // (task maple-83). Id and the shape of what was filed by default, the whole task on
  // verbose:true — the engine's return is unchanged for the CLI and the tests.
  hub_task_add: (a) => {
    const r = runTaskAdd(a);
    if (a.verbose) return r;
    const t = r.task || {};
    return { ok: true, id: t.id, project: t.project, by: t.by, importance: t.importance, cat: t.cat ?? null,
      ...(t.assignee ? { assignee: t.assignee } : {}), ...(t.deadline ? { deadline: t.deadline } : {}),
      textPreview: String(t.text || '').slice(0, 80) + (String(t.text || '').length > 80 ? '…' : '') };
  },
  hub_task_list: runTaskList, hub_task_update: runTaskUpdate,
  // cost: only once the hub holds sessions; a ledger it cannot read never costs the task itself
  hub_task_get: (a) => {
    const r = runTaskGet(a);
    let cost = null; try { cost = taskCost(r.task.id); } catch {}
    return cost ? { ...r, cost } : r;
  },
  hub_stats: runStats,
  // root: teamRoot() captured synchronously here, same reasoning as hub_queue_send/wait below —
  // a plain string value, not a live reference, so a concurrent HTTP request repointing
  // HUB can't retarget an in-flight call.
  hub_brief: (a) => briefWithQueues({ ...a, root: teamRoot() }),
  // queues are read HERE and handed in: lib/queue.mjs imports core, so core cannot read them
  // itself without closing an import cycle (see runAudit).
  hub_audit: (a) => runAudit({ ...a, queues: queueSummaryForBrief({ root: teamRoot() }) }),
  hub_lint: runLint,
  hub_next: runNext, hub_agenda: runAgenda, hub_recall: runRecall, hub_reflect: (a) => (a.promote ? runPromote(a) : runReflect(a)), hub_law: runLaw,
  hub_usage: runUsage, hub_usage_add: runUsageAdd,
  hub_rules: (a) => runRules({ ...a, teamRoot: teamRoot() }), hub_operator: () => runOperatorGet(),
  hub_kanban: runKanban, hub_claim: runClaim, hub_claim_check: runClaimCheck, hub_release: runRelease,
  hub_heartbeat: runHeartbeat, hub_presence: runPresence,
  hub_resource_set: runResourceSet, hub_resource_list: runResourceList, hub_resource_get: runResourceGet, hub_graph: runGraph,
  // session: over HTTP the process-derived session id is the SERVER's own, one value
  // for every remote caller — keying whatsnew checkpoints on it would make the whole
  // team share one "what did I miss". Null there; the agent label becomes the key.
  hub_onboarding: (a) => runOnboarding(a),
  // queues: same hand-off as hub_brief — the review block rides on this call and its stale-button
  // check needs rows core.mjs cannot read for itself.
  hub_whatsnew: (a) => runWhatsNew({ ...a, queues: queueSummaryForBrief({ root: teamRoot() }),
    session: SERVE_MODE === 'http' ? null : sessionId(), transport: SERVE_MODE }),
  hub_inbox: runInbox, hub_trajectory: runTrajectory,
  // root: teamRoot() is captured HERE, synchronously, at call time — a plain string value,
  // not a live reference — so it stays correct even if a later concurrent request
  // repoints the HUB global while hub_queue_wait's promise is still pending.
  // from: required like every other author (was `|| 'mcp'` — a transport name, i.e. a
  // placeholder); an omitted from is filled by the HUBD_AGENT floor in withAuthorFloor.
  hub_queue_send: (a) => queueSendChecked(a.role, a.text, { from: a.from, root: teamRoot(), task: a.task, remote: a.local === false }),
  // subscriber: subscriberId() — stable across a respawn (HUBD_SUBSCRIBER / HUBD_SESSION /
  // HUBD_AGENT before the process id), so a restarted role resumes its own position.
  // Resolved from THIS process, never from the caller's arguments — the
  // model cannot forget it or invent a different one mid-loop. Null on an unknown
  // client, and then the cursor stays shared per node exactly as before.
  hub_queue_wait: (a) => queueWait(a.role, { timeout: Math.min(a.timeout || 45, 540), root: teamRoot(), subscriber: subscriberId(), work: !!a.tasks }),
  hub_queue_wait_all: (a) => queueWaitAll({ timeout: Math.min(a.timeout || 45, 540), root: teamRoot(), subscriber: subscriberId() }),
  hub_queue_ack: (a) => queueAck(a.role, a.id, { root: teamRoot() }),
};

// Where the queues and AGENTS.md live for THIS server. The CLI resolves the team root as
// HUBD_TEAM_DIR, then a walk-up from cwd, then the hub base; the server has no meaningful cwd
// (the client picks it), so the walk-up is skipped, but the env var must count here exactly as it
// does in the CLI — until 0.9.17 the server used HUB unconditionally, and a client config that
// declared HUBD_TEAM_DIR for its hubd server got queues in ~/.hubd anyway (task maple-88).
// Over HTTP the per-request tenant dir is the whole world: one env var cannot name many tenants.
function teamRoot() {
  if (SERVE_MODE === 'http') return HUB;
  return process.env.HUBD_TEAM_DIR || process.env.HUBD_QUEUE_DIR || HUB;
}

// Tools that touch the server's own filesystem / run subprocesses, or block for a
// long time. Safe when the daemon runs locally for one owner (stdio); a hole (or a
// resource-exhaustion risk, for the blocking wait) on a shared network server where
// a remote agent could point `path` at the host's disk or hold a connection open for
// minutes. Disabled over HTTP.
const LOCAL_ONLY_TOOLS = new Set(['hub_sync', 'hub_queue_wait', 'hub_queue_wait_all']);

/* The tools a role works with. A client reads every tool's schema at the start of every session:
 * all of them came to 45k characters, about 11k tokens, which a local model reading 100-200 tokens
 * a second spends a minute and a half on before its first word. HUBD_TOOLS names a profile, tool
 * names, or both, comma-separated. A worker waits for a dispatch, does it, reports and asks; it
 * reads the hub, it does not run it (no tasks of its own, no cards, no laws). */
const TOOL_PROFILES = {
  worker: ['hub_context', 'hub_whatsnew', 'hub_rules', 'hub_get', 'hub_search', 'hub_resource_get',
    'hub_queue_wait', 'hub_queue_send', 'hub_queue_ack',
    'hub_task_get', 'hub_task_list', 'hub_task_update', 'hub_claim', 'hub_release', 'hub_report'],
};

// The tool tables are keyed by name in five places; a name in one and not the others is a tool
// offered with no handler, a handler never offered, or a budget for nothing. Refused at start,
// not found on the first call.
{
  const names = new Set(TOOLS.map(t => t.name));
  const stray = [...names].filter(n => !DISPATCH[n])
    .concat([...Object.keys(DISPATCH), ...Object.keys(OUTPUT_PLANS), ...LOCAL_ONLY_TOOLS,
      ...Object.values(TOOL_PROFILES).flat()].filter(n => !names.has(n)));
  if (stray.length) throw new Error('hubd: tool tables disagree on ' + [...new Set(stray)].join(', '));
}

// null: every tool. A word that is neither a profile nor a tool is said on stderr and left out;
// when nothing is left, every tool is offered, since a typo should cost tokens, not the hub.
const OFFERED = (() => {
  const raw = (process.env.HUBD_TOOLS || '').trim();
  if (!raw) return null;
  const names = new Set(TOOLS.map(t => t.name));
  const out = new Set(), unknown = [];
  for (const w of raw.split(/[\s,]+/).filter(Boolean)) {
    if (w === 'all') return null;
    if (TOOL_PROFILES[w]) TOOL_PROFILES[w].forEach(n => out.add(n));
    else if (names.has(w)) out.add(w);
    else unknown.push(w);
  }
  if (unknown.length) process.stderr.write(`hubd: HUBD_TOOLS: ${unknown.join(', ')}: no profile (${Object.keys(TOOL_PROFILES).join(', ')}, all) and no tool; left out\n`);
  if (!out.size) { process.stderr.write('hubd: HUBD_TOOLS names nothing this server has; every tool is offered\n'); return null; }
  return out;
})();

function offered(name, mode) {
  return !(mode === 'http' && LOCAL_ONLY_TOOLS.has(name)) && (!OFFERED || OFFERED.has(name));
}

function toolsFor(mode) {
  return TOOLS.filter(t => offered(t.name, mode));
}

// What a client is told at connect, one sentence per piece of advice. A sentence that names a tool
// this server does not offer is left out: advice to call a tool the model cannot see is the one
// kind it can only get wrong.
const INSTRUCTIONS = [
  'Shared sync point for all project folders and agents.',
  'New here? Call hub_onboarding first.',
  'In a project folder? Call hub_context({cwd:"<your absolute cwd>"}) to auto-resolve which project this is and its digest, instead of hub_get.',
  'Returning after time away? Call hub_whatsnew instead of re-reading hub_status from scratch.',
  'Resuming after a context compaction? hub_context({cwd}) first — it answers from state (digest age, who else is here, journal tail) — then hub_whatsnew({since:"session"}); the default checkpoint is empty for your own session.',
  'hub_brief gives a morning overview.',
  'Create work with hub_task_add.',
];
function instructionsFor(mode) {
  return INSTRUCTIONS.filter(s => (s.match(/hub_[a-z_]+/g) || []).every(n => offered(n, mode))).join(' ');
}

// Nudge state: has THIS connection called hub_onboarding / hub_whatsnew yet.
// stdio-only by construction (see call site below) — a module-level boolean is
// correct there because one stdio process serves exactly one agent session. It
// would be WRONG over HTTP, where one process serves many tenants concurrently
// and a shared flag would leak "tenant A onboarded" into tenant B's responses;
// hub_onboarding/hub_whatsnew themselves stay available over HTTP (their own
// state is file-backed per agent name), only the auto-nudge is skipped there.
let onboarded = false, whatsnewChecked = false;

// Fill agent/by/from from HUBD_AGENT when the caller left them out. All three are
// filled because tools disagree on which one they read (queue send reads `from`),
// and an unread extra key is ignored.
//
// The floor carries a per-session suffix, because HUBD_AGENT lives in a server's
// config — i.e. it is per MACHINE, and every session on that host would otherwise
// write under one name. That reproduces exactly the flaw requireAuthor refuses in
// "claude": one label many sessions, nothing to tell them apart afterwards. It also
// breaks two tools mechanically, because there the author is not a label but an
// identity key: runClaim treats an equal name as the same holder and reports no
// conflict, so two sessions would both "hold" one area and the soft lock would stop
// locking; and presence keeps one file per name, last write wins, so a fleet of
// sessions would collapse into a single record.
//
// The suffix is short and derived from the same process-resolved session id the queue
// cursors use, so it is stable for a client's whole life and survives a server
// respawn. An explicit author is never touched — a caller that names its own
// function writes exactly that, whichever of agent/by/from it named it under.
let floorCache;
function authorFloor() {
  if (floorCache !== undefined) return floorCache;
  // Over HTTP one process serves many agents (or tenants): HUBD_AGENT is the server
  // owner's env, and the session suffix would derive from the server's own parent —
  // one name for every caller, exactly the "one label, many sessions" collapse the
  // floor exists to prevent. No floor there; HTTP callers say who they are
  // explicitly (the tool schemas require it).
  if (SERVE_MODE === 'http') return (floorCache = '');
  const base = (process.env.HUBD_AGENT || '').trim();
  if (!base) return (floorCache = '');
  // The floor is held to the same rule as an argument, or it would launder a refused
  // name into an accepted one: HUBD_AGENT=claude would arrive as "claude-<session>",
  // which passes the check while still naming a model. A misconfigured floor is no
  // floor — callers then get the error that explains what to put there.
  try { requireAuthor(base, 'HUBD_AGENT'); }
  catch (e) { process.stderr.write('warning: HUBD_AGENT ignored — ' + e.message + '\n'); return (floorCache = ''); }
  const sess = sessionId();
  if (!sess) return (floorCache = base);
  let h = 0;
  for (const ch of sess) h = (Math.imul(h, 31) + ch.charCodeAt(0)) >>> 0;
  return (floorCache = `${base}-${h.toString(36).padStart(4, '0').slice(-4)}`);
}

/* "An explicit argument is never touched" was true of the KEY the caller used and false of
 * the author: hub_report reads `by ?? agent`, so hub_report({agent: "doc-auditor@proj-29"})
 * left `by` empty, the floor filled it, and `by` won — three decisions and a done went into the
 * append-only journal under "owner-desk-<session>" one minute after hub_task_add with the same
 * name under `by` was attributed correctly (task maple-75). Attribution that cannot be
 * corrected afterwards must not depend on which of three synonyms a tool happens to read. So:
 * when the caller named ANY author, the empty synonyms take that name; the floor only ever
 * fills a call that named nobody. */
const AUTHOR_KEYS = ['agent', 'by', 'from'];
function withAuthorFloor(args) {
  const out = { ...args };
  const given = AUTHOR_KEYS.map(k => out[k]).find(v => v != null && String(v).trim() !== '');
  const fill = given != null ? String(given).trim() : authorFloor();
  if (!fill) return args;
  for (const k of AUTHOR_KEYS) if (out[k] == null || String(out[k]).trim() === '') out[k] = fill;
  return out;
}

/* A tool's `required` is checked here, once, for every tool: hub_task_add called with `title`
 * instead of `text` used to file a task whose whole text was "undefined", because nothing
 * between the schema and the engine read the list. A blank string is as missing as an absent
 * key. An argument the tool does not know is named beside it, since a misspelling is the usual
 * reason a required one is missing. The author keys are left to requireAuthor, whose refusal
 * says what an author is and how this transport fills one in. */
function missingRequired(name, args, raw) {
  const schema = TOOLS.find(t => t.name === name)?.inputSchema;
  const missing = (schema?.required || []).filter(k => !AUTHOR_KEYS.includes(k) &&
    (args[k] == null || (typeof args[k] === 'string' && !args[k].trim())));
  if (!missing.length) return null;
  const props = schema.properties || {};
  const unknown = Object.keys(raw || {}).filter(k => !(k in props));
  const one = missing.length === 1 && props[missing[0]]?.description;
  return (one ? `${missing[0]} required: ${one}` : 'missing required: ' + missing.join(', ')) +
    (unknown.length ? ` (got ${unknown.join(', ')}, which ${name} does not take)` : '');
}

// One line: the count and where the list is. An upgrade can require something outside
// the code — a variable in this client's config, a role declared in the hub — and
// nothing used to say so; the agent found out by having a call rejected, or never.
// Deliberately not the list itself: a dump on every tool result is noise, and noise is
// how a notice stops being read. Recomputed at most every 5 minutes (was: once per
// process) — a long-lived server otherwise kept nagging about a condition fixed an
// hour ago, and stayed silent about one that appeared after startup, until a restart.
// Asked as THIS session, the one hub_whatsnew acknowledges: asked as nobody, a session that
// had already been told about a protocol change was told again on every result until the
// next release, because "nobody" never acknowledges anything.
// A session whose HUBD_TOOLS leaves hub_whatsnew out has nothing that acknowledges, and was told
// on every result until the next release all the same. There this line is the telling: said once,
// then recomputed on the next call, which no longer finds it.
let envNudgeLine = null, envNudgeAt = 0;
function envNudge() {
  if (envNudgeAt && Date.now() - envNudgeAt < 5 * 60000) return envNudgeLine;
  envNudgeAt = Date.now();
  let n = null;
  try {
    const session = SERVE_MODE === 'http' ? null : sessionId();
    const env = envChecks({ session, transport: SERVE_MODE });
    const hasWhatsnew = offered('hub_whatsnew', SERVE_MODE);
    if (env.total) n = `⚠ environment: ${env.total} item(s) need attention (${env.items[0].id}${env.total > 1 ? ', …' : ''}) — ${hasWhatsnew ? 'hub_whatsnew' : '`hub doctor`'} lists them with what to do.`;
    if (session && !hasWhatsnew && env.items.some(i => i.id === 'protocol-changed')) { ackEnvNotices(session); envNudgeAt = 0; }
  } catch {}
  return (envNudgeLine = n);
}

function nudges(name) {
  if (name === 'hub_onboarding' || name === 'hub_whatsnew') return [];
  const n = [];
  if (!onboarded && offered('hub_onboarding', 'stdio')) n.push({ type: 'text', text: '💡 New here? Call hub_onboarding first (one-time — how this hub works: claim vs task vs report vs queue).' });
  if (!whatsnewChecked && offered('hub_whatsnew', 'stdio')) n.push({ type: 'text', text: '💡 Call hub_whatsnew({agent:"<you>"}) to see what changed since you last checked in, instead of re-reading from scratch.' });
  const e = envNudge();
  if (e) n.push({ type: 'text', text: e });
  return n;
}

// Turn one JSON-RPC message into a response object (or null for a notification
// that needs no reply). Transport-agnostic — stdio and HTTP both route through
// here, so the protocol behaves identically on either. async because hub_queue_wait
// blocks; every other tool is still synchronous internally, so `await fn(...)`
// resolves on the next microtask with no observable delay for them.
async function handleMessage(msg, mode = 'stdio') {
  const { id, method, params } = msg;
  if (method === 'initialize') return { jsonrpc: '2.0', id, result: {
    protocolVersion: '2025-03-26', capabilities: { tools: { listChanged: false }, prompts: { listChanged: false } },
    serverInfo: { name: 'hubd', version: VERSION },
    // No "call hub_heartbeat after each hub_report" here: this text reaches every client, and a role
    // run by a shell loop has hub_heartbeat denied — the advice sent it to a tool it is refused. The
    // tool's own description carries it, and a client without the tool never sees that.
    instructions: instructionsFor(mode) } };
  if (String(method).startsWith('notifications/')) return null;
  if (method === 'ping') return { jsonrpc: '2.0', id, result: {} };
  if (method === 'tools/list') return { jsonrpc: '2.0', id, result: { tools: toolsFor(mode) } };
  // A role's rules are prompts too, rendered from this package's prompts/meta by the code behind
  // `hub prompts render`: a client with no rules file gets the installed version, not a copy.
  if (method === 'prompts/list') {
    let roles = [];   // a broken template costs the role prompts, not harvest
    try { roles = promptList(); } catch (e) { process.stderr.write('hubd: prompts/meta: ' + e.message + '\n'); }
    return { jsonrpc: '2.0', id, result: { prompts: [
      { name: 'harvest', description: 'Harvest this dialog into the hub — projects, tasks, decisions, links, open questions (the Harvest Protocol). No need to fetch HARVEST.md.' },
      ...roles,
    ] } };
  }
  if (method === 'prompts/get') {
    if (params?.name === 'harvest') {
      const text = harvestPrompt() || 'HARVEST.md not found in this hubd package.';
      return { jsonrpc: '2.0', id, result: { description: 'Harvest this dialog into the hub', messages: [{ role: 'user', content: { type: 'text', text } }] } };
    }
    if (templateNames().includes(params?.name)) {
      const a = params.arguments || {};
      let text;
      try { text = renderPrompt(params.name, a); }
      catch (e) { return { jsonrpc: '2.0', id, error: { code: e.args ? -32602 : -32603, message: e.message } }; }
      return { jsonrpc: '2.0', id, result: { description: `The ${params.name} rules` + (a.role ? ` of ${a.role}` : ''), messages: [{ role: 'user', content: { type: 'text', text } }] } };
    }
    return { jsonrpc: '2.0', id, error: { code: -32602, message: 'unknown prompt: ' + params?.name } };
  }
  if (method === 'tools/call') {
    const name = params?.name;
    if (mode === 'http' && LOCAL_ONLY_TOOLS.has(name))
      return { jsonrpc: '2.0', id, result: { content: [{ type: 'text', text: 'Error: ' + name + ' is disabled on a shared server (no server-side filesystem access). Use task/journal tools.' }], isError: true } };
    // What tools/list did not offer is not served either: the profile is the role's, not a menu.
    if (DISPATCH[name] && !offered(name, mode))
      return { jsonrpc: '2.0', id, result: { content: [{ type: 'text', text: 'Error: ' + name + ' is not offered by this server (HUBD_TOOLS=' + process.env.HUBD_TOOLS.trim() + ').' }], isError: true } };
    const fn = DISPATCH[name];
    if (!fn) return { jsonrpc: '2.0', id, result: { content: [{ type: 'text', text: 'Error: unknown tool: ' + name }], isError: true } };
    try {
      // HUBD_AGENT is the floor for attribution: it is set by whoever configured this
      // server, so "the caller forgot to say who it is" degrades to a real name from
      // the config instead of to a placeholder. An explicit argument always wins, so a
      // session that knows its own function can still be more specific than the floor.
      // `local: false` over HTTP, set here and never taken from the caller: it is what keeps
      // hub_context, hub_claim_check, hub_presence and the audit off the SERVER's filesystem, and
      // a tenant who could pass `local: true` would get that walk back.
      const argv = { ...withAuthorFloor(params?.arguments || {}), ...(mode === 'http' ? { local: false } : {}) };
      const missing = missingRequired(name, argv, params?.arguments);
      if (missing) throw new Error(missing);
      const r = await fn(argv);
      // A session that never heartbeats still says its node is up (refreshPresenceSnapshot).
      if (mode === 'stdio') refreshPresenceSnapshot();
      if (name === 'hub_onboarding') onboarded = true;
      if (name === 'hub_whatsnew') { whatsnewChecked = true; envNudgeAt = 0; }   // it just acknowledged
      const extra = mode === 'stdio' ? nudges(name) : [];
      // One choke point for every tool's size, so no new tool can forget it.
      // Under HUBD_PRESET=small without the indentation, about a sixth of every answer.
      const indent = SMALL ? 0 : 1;
      const capped = OUTPUT_PLANS[name] ? capOutput(r, OUTPUT_PLANS[name], { full: !!argv.full, indent }) : r;
      return { jsonrpc: '2.0', id, result: { content: [{ type: 'text', text: JSON.stringify(capped, null, indent) }, ...extra], isError: false } };
    } catch (e) {
      // A refusal the caller acts on by kind carries its code (queue-full), the way an exit code would.
      const code = e && typeof e.code === 'string' && /^[a-z]+(?:-[a-z]+)+$/.test(e.code) ? ' [' + e.code + ']' : '';
      return { jsonrpc: '2.0', id, result: { content: [{ type: 'text', text: 'Error' + code + ': ' + e.message }], isError: true } };
    }
  }
  return { jsonrpc: '2.0', id, error: { code: -32601, message: 'method not found: ' + method } };
}

/* ── stdio transport (default; one owner, local) ── */
function serveStdio() {
  const out = (obj) => process.stdout.write(JSON.stringify(obj) + '\n');
  const rl = readline.createInterface({ input: process.stdin, terminal: false });
  // async: a hub_queue_wait call can be in flight for minutes without blocking
  // the readline loop — other lines (other tool calls) keep being read and
  // processed concurrently; each writes its own JSON-RPC response (matched by
  // id) whenever its own promise settles, independent of call order.
  rl.on('line', async (line) => {
    line = line.trim();
    if (!line) return;
    let msg;
    try { msg = JSON.parse(line); } catch {
      return out({ jsonrpc: '2.0', id: null, error: { code: -32700, message: 'parse error' } });
    }
    const r = await handleMessage(msg, 'stdio');
    if (r) out(r);
  });
}

/* ── HTTP transport (shared hub; MCP over Streamable HTTP, POST JSON) ──
 * Two modes. Single-tenant: one HUBD_TOKEN gates the server's own hub. Multi-tenant
 * (HUBD_MULTITENANT=1): every token is its own isolated workspace at tenants/<hash>,
 * auto-created on first request — no signup, the token IS the key (use a strong one,
 * e.g. a uuid). hub_sync is disabled in both. Binds to localhost unless HUBD_HTTP_HOST
 * is set — put TLS + the open port in front yourself. Zero deps: node stdlib only. */
async function serveHttp(port) {
  const http = await import('node:http');
  const crypto2 = await import('node:crypto');
  const MT = process.env.HUBD_MULTITENANT === '1';
  const SERVER_BASE = HUB;                         // base captured at startup
  const TENANTS = path.join(SERVER_BASE, 'tenants');
  const TOKEN = process.env.HUBD_TOKEN || '';
  if (!MT && (!TOKEN || TOKEN.length < 16)) {
    process.stderr.write('hubd --http: set HUBD_TOKEN to a secret of 16+ chars, or HUBD_MULTITENANT=1 (token = workspace).\n');
    process.exit(1);
  }
  const host = process.env.HUBD_HTTP_HOST || '127.0.0.1';
  const MAX_BODY = 512 * 1024;

  // ── abuse guards (matter most on a public multi-tenant endpoint) ──
  // Without these, anyone can spray random tokens to mint unbounded tenant dirs
  // (disk-fill) or flood the server. Tunable via env; sane defaults.
  const fs2 = await import('node:fs');
  const RATE = parseInt(process.env.HUBD_RATE_LIMIT || '120', 10);   // POSTs/min per client IP
  const MAX_TENANTS = parseInt(process.env.HUBD_MAX_TENANTS || '1000', 10);
  const hits = new Map();                                            // ip -> { n, reset }
  const rateOk = (ip) => {
    const now = Date.now();
    if (hits.size > 10000) for (const [k, v] of hits) if (now > v.reset) hits.delete(k);
    let e = hits.get(ip);
    if (!e || now > e.reset) { e = { n: 0, reset: now + 60000 }; hits.set(ip, e); }
    e.n++;
    return e.n <= RATE;
  };
  const known = new Set();                                           // existing tenant hashes
  if (MT) { try { for (const d of fs2.readdirSync(TENANTS, { withFileTypes: true })) if (d.isDirectory()) known.add(d.name); } catch {} }
  // Behind a TLS proxy the real client is in X-Forwarded-For; fall back to the socket.
  const clientIp = (req) => ((req.headers['x-forwarded-for'] || '').split(',')[0].trim()) || req.socket?.remoteAddress || 'unknown';

  // Map a request's Bearer token to the directory it may touch, or null to reject.
  const tenantFor = (header) => {
    const m = /^Bearer (.+)$/.exec(header || '');
    if (!m) return null;
    const tok = m[1];
    if (MT) return tok.length >= 16 ? path.join(TENANTS, tenantKey(tok)) : null;
    const a = Buffer.from(tok), b = Buffer.from(TOKEN);
    return (a.length === b.length && crypto2.timingSafeEqual(a, b)) ? SERVER_BASE : null;
  };
  const sendJson = (res, code, obj) => {
    const body = JSON.stringify(obj);
    res.writeHead(code, { 'content-type': 'application/json', 'content-length': Buffer.byteLength(body) });
    res.end(body);
  };

  const server = http.createServer((req, res) => {
    if (req.method === 'GET' && req.url === '/healthz') return sendJson(res, 200, { ok: true, server: 'hubd', version: VERSION, mode: MT ? 'multi-tenant' : 'single-tenant' });
    if (req.method !== 'POST') { res.writeHead(405).end(); return; }
    if (!rateOk(clientIp(req))) { res.writeHead(429, { 'retry-after': '60' }).end(); return; }
    const tenant = tenantFor(req.headers['authorization']);
    if (!tenant) { res.writeHead(401, { 'www-authenticate': 'Bearer' }).end(); return; }
    if (MT) {                                  // cap NEW tenant creation; existing tenants keep working
      const h = path.basename(tenant);
      if (!known.has(h)) {
        if (known.size >= MAX_TENANTS) { res.writeHead(403).end(); return; }
        known.add(h);
      }
    }
    let body = '', tooBig = false;
    req.on('data', (c) => { body += c; if (body.length > MAX_BODY) { tooBig = true; req.destroy(); } });
    req.on('end', async () => {
      if (tooBig) return;
      let parsed;
      try { parsed = JSON.parse(body); } catch {
        return sendJson(res, 200, { jsonrpc: '2.0', id: null, error: { code: -32700, message: 'parse error' } });
      }
      // Every tool reachable over HTTP is still synchronous internally (LOCAL_ONLY_TOOLS
      // keeps hub_queue_wait off this transport), so setHubBase(tenant) here is never
      // at risk of being repointed mid-flight by a concurrent request's own setHubBase.
      setHubBase(tenant);
      ensureHubDirs();   // a tenant's workspace exists from its first request, as it always has
      if (Array.isArray(parsed)) {
        const results = await Promise.all(parsed.map((m) => handleMessage(m, 'http')));
        return sendJson(res, 200, results.filter(Boolean));
      }
      const r = await handleMessage(parsed, 'http');
      return sendJson(res, 200, r ?? {});
    });
  });
  server.listen(port, host, () => {
    process.stderr.write(`hubd serving MCP over HTTP on ${host}:${port} (${MT ? 'multi-tenant, token = workspace' : 'single-tenant'}, hub_sync disabled)\n`);
  });
}

const httpPortArg = (() => {
  const i = process.argv.indexOf('--http');
  if (i !== -1) return parseInt(process.argv[i + 1] || process.env.HUBD_HTTP_PORT || '8787', 10);
  if (process.env.HUBD_HTTP_PORT) return parseInt(process.env.HUBD_HTTP_PORT, 10);
  return null;
})();

// Which transport this process serves — set once, before any request is handled.
// The author floor and the environment checks read it: both describe THIS process's
// env, which is only the caller's environment on a local (stdio) transport.
const SERVE_MODE = httpPortArg ? 'http' : 'stdio';
setAuthorTransport(SERVE_MODE);

try { ensureProtocol(); } catch {}   // materialise HUBD.md for this hub on daemon start
if (httpPortArg) serveHttp(httpPortArg); else serveStdio();
